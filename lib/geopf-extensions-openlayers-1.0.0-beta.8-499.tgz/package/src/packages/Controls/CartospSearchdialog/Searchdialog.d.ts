export default Searchdialog;
/**
 * @classdesc
 *
 * Searchdialog button
 *
 * @constructor
 * @alias ol.control.Searchdialog
 * @type {ol.control.Searchdialog}
 * @extends {ol.control.Control}
 * @param {Object} options - options for function call.
 *
 * @fires view:change
 * @example
 * var searchdialog = new ol.control.Searchdialog();
 * map.addControl(Searchdialog);
 */
declare var Searchdialog: ol.control.Searchdialog;
//# sourceMappingURL=Searchdialog.d.ts.map