export default SearchdialogDOM;
declare namespace SearchdialogDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createShowSearchdialogPictoElement(): DOMElement;
    function _createSearchdialogPanelElement(): DOMElement;
    function _createSearchdialogPanelDivElement(): HTMLDivElement;
    function _createSearchdialogPanelContentElement(): HTMLDivElement;
    function _createSearchdialogPanelTitleDivElement(): HTMLDivElement;
    function _createSearchdialogPanelHeaderElement(): DOMElement;
    function _createSearchdialogPanelCloseElement(): HTMLButtonElement;
}
//# sourceMappingURL=SearchdialogDOM.d.ts.map