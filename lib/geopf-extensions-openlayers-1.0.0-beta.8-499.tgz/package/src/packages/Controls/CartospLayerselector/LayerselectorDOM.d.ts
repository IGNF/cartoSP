export default LayerselectorDOM;
declare namespace LayerselectorDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createShowLayerselectorPictoElement(): DOMElement;
    function _createLayerselectorPanelElement(): DOMElement;
    function _createLayerselectorPanelDivElement(): HTMLDivElement;
    function _createLayerselectorPanelContentElement(): HTMLDivElement;
    function _createLayerselectorPanelHeaderElement(): DOMElement;
    function _createLayerselectorPanelCloseElement(): HTMLButtonElement;
    function _createSelectorEntries(o: any, l: any): HTMLElement;
    function _createLayerselectorElement(): HTMLDivElement;
}
//# sourceMappingURL=LayerselectorDOM.d.ts.map