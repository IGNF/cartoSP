export default Layerselector;
/**
 * @classdesc
 *
 * Layerselector button
 *
 * @constructor
 * @alias ol.control.Layerselector
 * @type {ol.control.Layerselector}
 * @extends {ol.control.Control}
 * @param {Object} options - options for function call.
 *
 * @fires view:change
 * @example
 * var layerselector = new ol.control.Layerselector();
 * map.addControl(layerselector);
 */
declare var Layerselector: ol.control.Layerselector;
//# sourceMappingURL=Layerselector.d.ts.map