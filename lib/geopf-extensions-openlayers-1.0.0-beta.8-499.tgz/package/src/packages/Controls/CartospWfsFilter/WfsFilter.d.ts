export default WfsFilter;
/**
 * @classdesc
 *
 * WfsFilter button
 *
 * @constructor
 * @alias ol.control.WfsFilter
 * @type {ol.control.WfsFilter}
 * @extends {ol.control.Control}
 * @param {Object} options - options for function call.
 *
 * @fires view:change
 * @example
 * var wfsfilter = new ol.control.WfsFilter();
 * map.addControl(wfsfilter);
 */
declare var WfsFilter: ol.control.WfsFilter;
//# sourceMappingURL=WfsFilter.d.ts.map