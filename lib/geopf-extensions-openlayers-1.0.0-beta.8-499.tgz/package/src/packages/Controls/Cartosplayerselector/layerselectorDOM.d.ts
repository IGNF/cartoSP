export default LayerselectorDOM;
declare namespace LayerselectorDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createShowLayerselectorPictoElement(): DOMElement;
    function _createLayerselectorPanelElement(): DOMElement;
    function _createLayerselectorPanelDivElement(): HTMLDivElement;
    function _createLayerselectorPanelContentElement(): HTMLDivElement;
    function _createLayerselectorPanelTitleDivElement(): HTMLDivElement;
    function _createLayerselectorPanelHeaderElement(): DOMElement;
    function _createLayerselectorPanelCloseElement(): HTMLButtonElement;
    function _createThematiqueResetLink(): HTMLDivElement;
    function _createThematiqueEntry(o: any): ShadowRoot;
    function _createEmptyThematique(): HTMLDivElement;
    function _createLayerselectorElement(): HTMLDivElement;
}
//# sourceMappingURL=layerselectorDOM.d.ts.map