export default Indicator;
/**
 * @classdesc
 *
 * Indicator button
 *
 * @constructor
 * @alias ol.control.Indicator
 * @type {ol.control.Indicator}
 * @extends {ol.control.Control}
 * @param {Object} options - options for function call.
 *
 * @fires view:change
 * @example
 * var indicator = new ol.control.Indicator();
 * map.addControl(Indicator);
 */
declare var Indicator: ol.control.Indicator;
//# sourceMappingURL=Indicator.d.ts.map