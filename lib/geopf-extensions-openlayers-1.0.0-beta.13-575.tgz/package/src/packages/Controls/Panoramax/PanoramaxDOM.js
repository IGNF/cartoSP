var title = "Panoramax";

var PanoramaxDOM = {

    /**
    * Add uuid to the tag ID
    * @param {String} id - id selector
    * @returns {String} uid - id selector with an unique id
    */
    _addUID : function (id) {
        var uid = (this.uid) ? id + "-" + this.uid : id;
        return uid;
    },

    /**
     * Main container (DOM)
     *
     * @returns {DOMElement} DOM element
     */
    _createMainContainerElement : function () {
        var container = document.createElement("div");
        container.id = this._addUID("GPpanoramax");
        container.className = "GPwidget gpf-widget gpf-widget-button gpf-mobile-fullscreen";
        return container;
    },

    // ################################################################### //
    // ################### Methods of main container ##################### //
    // ################################################################### //

    /**
     * Show Widget
     *
     * @returns {DOMElement} DOM element
     */
    _createShowWidgetPictoElement : function () {
        var self = this;

        var button = document.createElement("button");
        // INFO: Ajout d'une SPAN pour enlever des marges de 6px dans CHROMIUM (?!)
        var span = document.createElement("span");
        button.appendChild(span);
        button.id = this._addUID("GPshowPanoramaxPicto");
        button.title = `${title}`;
        button.classList.add("GPshowOpen", "GPshowAdvancedToolPicto", "GPshowPanoramaxPicto");
        button.classList.add("gpf-btn", "gpf-btn--tertiary", "gpf-btn-icon", "gpf-btn-icon-panoramax");
        // button.classList.add("icon--ri", "icon--ri--map-2-line");
        button.classList.add("fr-btn", "fr-btn--tertiary");
        button.setAttribute("tabindex", "0");
        button.setAttribute("aria-pressed", false);
        button.setAttribute("aria-label", `Parcourir les photos ${title}`);
        button.setAttribute("type", "button");

        // Close all results and panels when minimizing the widget
        button.addEventListener("click", function (e) {
            var status = (button.getAttribute("aria-pressed") === "true");
            button.setAttribute("aria-pressed", !status);
            self.onShowPanoramaxClick(e);
        });

        return button;
    },

    // ################################################################### //
    // ################ Methods of panel buttons container ############### //
    // ################################################################### //

    /**
     * Create Container Panel for buttons
     *
     * @returns {DOMElement} DOM element
     */
    _createWidgetPanelButtonsElement : function () {
        var dialog = document.createElement("dialog");
        dialog.id = this._addUID("GPpanoramaxPanelButtons");
        dialog.className = "GPpanel pnx-buttons-window-panel gpf-panel fr-modal";
        return dialog;
    },
    
    _createWidgetPanelButtonsDivElement : function () {
        var div = document.createElement("div");
        div.className = "pnx-buttons-panel__body gpf-panel__body fr-modal__body";
        div.classList.add("gpf-visible");
        return div;
    },

    // ################################################################### //
    // ####################### Methods for buttons ####################### //
    // ################################################################### //
    
    /**
     * Create buttons
     * see evenement !
     *
     * @returns {DOMElement} DOM element
     */
    _createWidgetButtonsElement : function () {
        var div = document.createElement("div");
        div.className = "pnx-buttons-panel__content";

        return div;
    },

    _createButtonOptionsElement : function () {
        var self = this;
        // <button type="button" class="fr-btn fr-icon-equalizer-line fr-btn--icon-right fr-btn--secondary">Filtrer</button>
        var button = document.createElement("button");
        button.id = this._addUID("GPpanoramaxButtonOptions");
        button.className = "gpf-btn gpf-btn-icon gpf-btn-icon-background";
        button.classList.add("fr-btn", "fr-icon-equalizer-line", "fr-btn--icon-right", "fr-btn--secondary");
        button.title = "Options";
        button.setAttribute("aria-label", "Options");
        button.setAttribute("aria-pressed", "false");
        button.setAttribute("type", "button");
        button.textContent = "Options";

        button.addEventListener("click", function (e) {
            var status = (e.target.getAttribute("aria-pressed") === "true");
            e.target.setAttribute("aria-pressed", !status);
            self.onOpenPanoramaxOptionsClick(e);
        });
        
        return button;
    },

    _createWidgetPanelOptionsElement : function () {
        // TODO : faire un dialog pour les options ? ou un panel classique ? à voir
        var panel = document.createElement("form");
        panel.id = this._addUID("GPpanoramaxPanelOptions");
        panel.className = "GPpanel pnx-options-panel gpf-panel gpf-hidden fr-modal";
        panel.setAttribute("aria-label", "Panneau des options Panoramax");

        return panel;
    },

    _createWidgetPanelOptionsDivElement : function () {
        let div = document.createElement("div");
        div.className = "gpf-panel__body fr-modal__body";
        return div;
    },

    // ################################################################### //
    // ####################### Methods for options ####################### //
    // ################################################################### //

    _createButtonContributionsElement : function (opts) {
        // <a href="[url - à modifier]" target="_self" class="fr-btn fr-icon-external-link-fill fr-btn--icon-right fr-btn--secondary">Contribuer</a>
        var href = document.createElement("a");
        href.id = this._addUID("GPpanoramaxButtonContributions");
        href.className = "fr-btn fr-btn--sm fr-icon-external-link-fill fr-btn--icon-right fr-btn--secondary";
        href.classList.add("gpf-btn");
        href.title = opts.description;
        href.setAttribute("aria-label", opts.description);
        href.setAttribute("target", "_blank");
        href.setAttribute("href", opts.link);
        href.textContent = opts.label;

        return href;
    },

    _createButtonChoiceHoverElement : function (active, opts) {
        var self = this;

        var div = document.createElement("div");
        div.id = this._addUID("GPpanoramaxToggle");
        div.className = "pnx-toggle fr-toggle fr-m-2v";

        var messages = document.createElement("div");
        messages.id = this._addUID("GPpanoramaxToggleMessages");
        messages.className = "fr-messages-group";
        messages.setAttribute("aria-live", "polite");
        
        var input = document.createElement("input");
        input.id = this._addUID("GPpanoramaxToggleInput");
        input.className = "pnx-toggle__input fr-toggle__input";
        input.type = "checkbox";
        input.checked = active;
        input.setAttribute("aria-describedby", messages.id);

        input.addEventListener("click", function (e) {
            self.onToggleChoiceHoverPanoramaxClick(e);
        });

        var label = document.createElement("label");
        label.id = this._addUID("GPpanoramaxToggleLabel");
        label.className = "pnx-toggle__label fr-toggle__label";
        label.setAttribute("title", opts.description);
        label.setAttribute("for", input.id);
        label.innerText = opts.label;

        div.appendChild(input);
        div.appendChild(label);
        div.appendChild(messages);

        return div;
    },

    /**
     * Crée un sélecteur de rendu de carte.
     * @param {Object} opts - Configuration du bouton de styles.
     * @returns {HTMLElement} DOM element
     */
    _createButtonChoiceStyleElement : function (opts) {
        var items = ["Classique", "Type de camera", "Date de prise de vue"];
        if (
            opts &&
            opts.content &&
            Array.isArray(opts.content) &&
            opts.content.length
        ) {
            items = opts.content;
        }

        var self = this;
        var container = document.createElement("div");
        container.id = this._addUID("GPpanoramaxStyleChoice");
        container.className = "pnx-style-choice fr-select-group fr-m-2v";

        var label = document.createElement("label");
        label.className = "fr-label fr-icon-palette-line fr-label--icon-left gpf-icon-color";
        label.setAttribute("for", this._addUID("GPpanoramaxStyleChoiceSelect"));
        label.innerText = (opts && opts.label) || "Rendu";

        var select = document.createElement("select");
        select.id = this._addUID("GPpanoramaxStyleChoiceSelect");
        select.className = "fr-select";
        select.disabled = true; // désactivé par défaut, il s'active une fois les rendus disponibles
        select.setAttribute("title", (opts && opts.description) || "Selectionner un rendu de carte");

        for (var i = 0; i < items.length; i++) {
            var option = document.createElement("option");
            option.value = items[i];
            option.innerText = items[i];
            if (i === 0) {
                option.selected = true;
            }
            select.appendChild(option);
        }

        select.addEventListener("change", function (e) {
            self.onSelectPanoramaxRenderClick(e);
        });

        container.appendChild(label);
        container.appendChild(select);

        return container;
    },

    _createButtonChoiceBackgroundElement : function (active, opts) {
        var self = this;

        var div = document.createElement("div");
        div.id = this._addUID("GPpanoramaxToggleBackground");
        div.className = "pnx-toggle fr-toggle fr-m-2v";

        var messages = document.createElement("div");
        messages.id = this._addUID("GPpanoramaxToggleBackgroundMessages");
        messages.className = "fr-messages-group";
        messages.setAttribute("aria-live", "polite");
        
        var input = document.createElement("input");
        input.id = this._addUID("GPpanoramaxToggleBackgroundInput");
        input.className = "pnx-toggle__input fr-toggle__input";
        input.type = "checkbox";
        input.checked = active;
        input.setAttribute("aria-describedby", messages.id);

        input.addEventListener("click", function (e) {
            self.onToggleChoiceBackgroundPanoramaxClick(e);
        });

        var label = document.createElement("label");
        label.id = this._addUID("GPpanoramaxToggleBackgroundLabel");
        label.className = "pnx-toggle__label fr-toggle__label";
        label.setAttribute("title", opts.description);
        label.setAttribute("for", input.id);
        label.innerText = opts.label;

        div.appendChild(input);
        div.appendChild(label);
        div.appendChild(messages);

        return div;
    },

    _createButtonChoiceDisplayLayerElement : function (active, opts) {
        var self = this;

        var div = document.createElement("div");
        div.id = this._addUID("GPpanoramaxToggleDisplay");
        div.className = "pnx-toggle fr-toggle fr-m-2v";

        var messages = document.createElement("div");
        messages.id = this._addUID("GPpanoramaxToggleDisplayMessages");
        messages.className = "fr-messages-group";
        messages.setAttribute("aria-live", "polite");
        
        var input = document.createElement("input");
        input.id = this._addUID("GPpanoramaxToggleDisplayInput");
        input.className = "pnx-toggle__input fr-toggle__input";
        input.type = "checkbox";
        input.checked = active;
        input.setAttribute("aria-describedby", messages.id);

        input.addEventListener("click", function (e) {
            self.onToggleChoiceDisplayLayerPanoramaxClick(e);
        });

        var label = document.createElement("label");
        label.id = this._addUID("GPpanoramaxToggleDisplayLabel");
        label.className = "pnx-toggle__label fr-toggle__label";
        label.setAttribute("title", opts.description);
        label.setAttribute("for", input.id);
        label.innerText = opts.label;

        div.appendChild(input);
        div.appendChild(label);
        div.appendChild(messages);

        return div;
    },

    // ################################################################### //
    // ####################### Methods for filters ####################### //
    // ################################################################### //

    _createWidgetPanelFiltersElement : function (opts) {
        var panel = document.createElement("div");
        panel.id = this._addUID("GPpanoramaxPanelFilters");
        panel.className = "pnx-filters-panel gpf-panel__content";
        panel.setAttribute("role", "region");
        panel.setAttribute("aria-label", opts.description || "Panneau des filtres Panoramax");

        if (opts.content.periodes || opts.content.dates) {
            let fieldset = this._createGroupFiltersByDateFieldsetElement();

            if (opts.content.periodes) {
                var periodes = [
                    { text : "1 mois", value : 1 },
                    { text : "6 mois", value : 6 },
                    { text : "1 an", value : 12 }
                ];
                var PeriodeGroup = this._createGroupFiltersByPeriodeElement(periodes);
                fieldset.appendChild(PeriodeGroup);
            }

            if (opts.content.dates) {
                var dateGroup = this._createGroupFiltersByDateElement();
                fieldset.appendChild(dateGroup);

                var startDateGroup = this._createGroupFiltersByStartDateElement();
                dateGroup.appendChild(startDateGroup);
                
                var endDateGroup = this._createGroupFiltersByEndDateElement();
                dateGroup.appendChild(endDateGroup);
            }

            panel.appendChild(fieldset);
        }
        
        if (opts.content.types) {
            var values = ["Tout", "Classique", "360°"];
            var typeGroup = this._createGroupFiltersByTypeElement(values);
            panel.appendChild(typeGroup);
        }
        
        panel.addEventListener("click", function (e) {
            e.stopPropagation();
        });

        // container pour des boutons
        var div = document.createElement("div");
        div.className = "pnx-filters-panel-buttons";
        panel.appendChild(div);

        return panel;
    },

    _createButtonResetFiltersElement : function (opts) {
        var self = this;
        // <button type="button" class="fr-btn fr-icon-equalizer-line fr-btn--icon-right fr-btn--secondary">Filtrer</button>
        var button = document.createElement("button");
        button.id = this._addUID("GPpanoramaxButtonResetFilters");
        button.className = "gpf-btn";
        button.classList.add("fr-btn", "fr-btn--sm", "fr-btn--tertiary-no-outline");
        button.title = opts.description;
        button.setAttribute("aria-label", opts.description);
        button.setAttribute("aria-pressed", "false");
        button.setAttribute("type", "button");
        button.textContent = opts.label;

        button.addEventListener("click", function (e) {
            var status = (e.target.getAttribute("aria-pressed") === "true");
            e.target.setAttribute("aria-pressed", !status);
            self.onResetPanoramaxFiltersClick(e);
        });

        return button;
    },

    _createGroupFiltersByPeriodeElement : function (periodes) {
        var self = this;

        var PeriodeGroup = document.createElement("div");
        PeriodeGroup.className = "fr-fieldset__element pnx-filters-panel__date-predefined";

        let tagGroup = document.createElement("div");
        tagGroup.classList.add("fr-tags-group");
        PeriodeGroup.appendChild(tagGroup);

        for (var i = 0; i < periodes.length; i++) {
            var fieldsetElement = document.createElement("div");
            fieldsetElement.className = "gpf-fieldset__element";

            var buttonPeriode = document.createElement("button");
            buttonPeriode.className = "fr-tag fr-tag--sm";
            buttonPeriode.setAttribute("type", "button");
            buttonPeriode.setAttribute("aria-pressed", "false");
            buttonPeriode.dataset.filters = "group-filter-periodes";
            buttonPeriode.name = "group-filter-periodes";
            buttonPeriode.innerText = periodes[i].text;
            buttonPeriode.value = periodes[i].value;

            buttonPeriode.addEventListener("click", function (e) {
                var currentButton = e.currentTarget || e.target;
                var status = (currentButton.getAttribute("aria-pressed") === "true");
                currentButton.setAttribute("aria-pressed", !status);

                var groupName = currentButton.dataset.filters;
                var groupButtons = PeriodeGroup.querySelectorAll("[data-filters='" + groupName + "']");

                for (var j = 0; j < groupButtons.length; j++) {
                    if (groupButtons[j] !== currentButton) {
                        groupButtons[j].setAttribute("aria-pressed", "false");
                    }
                }

                self.onClickPanoramaxFilterByPeriode(e);
            });

            fieldsetElement.appendChild(buttonPeriode);
            tagGroup.appendChild(fieldsetElement);
        }

        return PeriodeGroup;
    },
    _createGroupFiltersByDateFieldsetElement : function () {
        let fieldset = document.createElement("fieldset");
        fieldset.classList.add("fr-fieldset");

        let legend = document.createElement("legend");
        legend.classList.add("fr-fieldset__legend", "fr-fieldset__legend--regular");
        legend.innerText = "Date";
        fieldset.appendChild(legend);

        return fieldset;
    },
    _createGroupFiltersByDateElement : function () {
        var dateGroup = document.createElement("div");
        dateGroup.className = "fr-fieldset__element pnx-filters-panel__date gpf-input-group fr-pb-2w";
        
        return dateGroup;
    },
    _createGroupFiltersByStartDateElement : function () {
        var self = this;

        var startDateGroup = document.createElement("div");
        startDateGroup.className = "pnx-filters-panel__date-start gpf-input-group fr-mb-1w";

        let id = this._addUID("GPpanoramaxFilterDateStart");

        var label = document.createElement("label");
        label.className = "fr-label";
        label.htmlFor = id;
        label.innerText = "De";
        startDateGroup.appendChild(label);

        var startDateInput = document.createElement("input");
        startDateInput.id = this._addUID("GPpanoramaxFilterDateStart");
        startDateInput.className = "fr-input gpf-input-date";
        startDateInput.setAttribute("type", "date");
        startDateInput.dataset.filters = "group-filter-dates";
        startDateInput.name = "group-filter-dates";
        startDateInput.addEventListener("change", function (e) {
            self.onChangePanoramaxFilterByDates(e);
        });

        startDateGroup.appendChild(startDateInput);

        return startDateGroup;
    },
    _createGroupFiltersByEndDateElement : function () {
        var self = this;

        var endDateGroup = document.createElement("div");
        endDateGroup.className = "pnx-filters-panel__date-end gpf-input-group fr-mb-1w";

        let id = this._addUID("GPpanoramaxFilterDateEnd");

        var label = document.createElement("label");
        label.className = "fr-label";
        label.htmlFor = id;
        label.innerText = "À";
        endDateGroup.appendChild(label);

        var endDateInput = document.createElement("input");
        endDateInput.id = id;
        endDateInput.className = "fr-input gpf-input-date";
        endDateInput.setAttribute("type", "date");
        endDateInput.dataset.filters = "group-filter-dates";
        endDateInput.name = "group-filter-dates";
        endDateInput.addEventListener("change", function (e) {
            self.onChangePanoramaxFilterByDates(e);
        });

        endDateGroup.appendChild(endDateInput);

        return endDateGroup;
    },
    _createGroupFiltersByTypeElement : function (values) {
        var self = this;

        var typeGroup = document.createElement("div");
        typeGroup.className = "pnx-filters-panel__type gpf-select-group fr-mb-8v";

        var segmentedFieldset = document.createElement("fieldset");
        segmentedFieldset.className = "gpf-segmented fr-segmented";

        var segmentedLegend = document.createElement("legend");
        segmentedLegend.className = "fr-segmented__legend";
        segmentedLegend.innerText = "Type d'image";
        segmentedFieldset.appendChild(segmentedLegend);

        var segmentedElements = document.createElement("div");
        segmentedElements.className = "fr-segmented__elements";
        segmentedElements.dataset.filters = "group-filter-types";
        segmentedFieldset.appendChild(segmentedElements);

        for (var i = 0; i < values.length; i++) {
            var item = values[i];
            var segmentedElement = document.createElement("div");
            segmentedElement.className = "gpf-segmented__element fr-segmented__element";
            segmentedElements.appendChild(segmentedElement);

            var input = document.createElement("input");
            input.value = i;
            input.checked = (i === 0); // cocher le premier élément par défaut
            input.dataset.default = (i === 0);
            input.type = "radio";
            input.id = "filter-type-segmented-" + i;
            input.name = "group-filter-types";
            input.addEventListener("change", function (e) {
                // uncheck all buttons in the group
                var groupName = e.target.parentElement.parentElement.dataset.filters;
                var groupButtons = segmentedFieldset.querySelectorAll("[data-filters='" + groupName + "'] input");
                for (var j = 0; j < groupButtons.length; j++) {
                    if (groupButtons[j] !== e.target) {
                        groupButtons[j].checked = false;
                    }
                }
                var index = parseInt(e.target.value, 10);
                self.onChangePanoramaxFilterByType(e, values[index]);
            });
            segmentedElement.appendChild(input);

            var label = document.createElement("label");
            label.className = "fr-label";
            label.htmlFor = "filter-type-segmented-" + i;
            label.innerText = item;
            segmentedElement.appendChild(label);
        }

        typeGroup.appendChild(segmentedFieldset);
        return typeGroup;
    },

    // ################################################################### //
    // ################ Methods of panel viewer container ################ //
    // ################################################################### //

    /**
     * Create Container Panel for photoviewer
     * 
     * @param {Boolean} display - true if the panel header must be displayed, false otherwise
     * @returns {DOMElement} DOM element
     */
    _createWidgetPanelViewerElement : function (display) {
        var dialog = document.createElement("dialog");
        dialog.id = this._addUID("GPpanoramaxPanelViewer");
        dialog.className = "GPpanel pnx-visualization-window-panel gpf-panel fr-modal";
        dialog.classList.add("gpf-hidden"); // la fenêtre de visualisation est masquée par défaut, elle s'affiche au clic sur une image
        
        // INFO
        // on desactive le header de la fenêtre de visualisation
        // var header = document.createElement("div");
        // header.className = "pnx-visualization-window-panel__header gpf-panel__header fr-modal__header";
        // if (!display) {
        //     header.classList.add("gpf-hidden");
        // }

        // INFO
        // on desactive cette partie du header pour ne pas avoir de bouton retour 
        // dans la fenêtre de visualisation
        // header.appendChild(this._createWidgetPanelButtonsReturnElement());
        // header.appendChild(this._createWidgetPanelButtonsCloseElement());

        // dialog.appendChild(header);
        return dialog;
    },
    
    _createWidgetPanelViewerDivElement : function () {
        var div = document.createElement("div");
        div.className = "pnx-visualization-window-panel__body gpf-panel__body fr-modal__body";
        div.classList.add("gpf-hidden");
        // Target tag for the photoviewer dialog (see Panoramax.js)
        return div;
    },
};

export default PanoramaxDOM;