export default WfsFilterDOM;
declare namespace WfsFilterDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createShowWfsfilterPictoElement(): DOMElement;
    function _createWfsfilterPanelElement(): DOMElement;
    function _createWfsfilterPanelDivElement(): HTMLDivElement;
    function _createWfsfilterPanelContentElement(): HTMLDivElement;
    function _createWfsfilterPanelHeaderElement(): DOMElement;
    function _createWfsfilterPanelCloseElement(): HTMLButtonElement;
    function _createFilterDiv(): HTMLDivElement;
    function _createFilterInfosDiv(): HTMLDivElement;
    function _createFilterContent(): ShadowRoot;
    function _createThematiqueResetLink(): HTMLDivElement;
    function _createThematiqueEntry(o: any): ShadowRoot;
    function _createEmptyThematique(): HTMLDivElement;
    function _createWfsfilterElement(): HTMLDivElement;
}
//# sourceMappingURL=WfsFilterDOM.d.ts.map