export default IndicatorDOM;
declare namespace IndicatorDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): DOMElement;
    function _createShowIndicatorPictoElement(): DOMElement;
    function _createIndicatorPanelElement(): DOMElement;
    function _createIndicatorPanelDivElement(): HTMLDivElement;
    function _createIndicatorPanelContentElement(): HTMLDivElement;
    function _createIndicatorPanelTitleDivElement(): HTMLHeadingElement;
    function _createIndicatorPanelTitleIconElement(): HTMLSpanElement;
    function _createIndicatorPanelHeaderElement(): DOMElement;
    function _createIndicatorPanelCloseElement(): HTMLButtonElement;
    function _createThematiqueResetLink(): HTMLDivElement;
    function _createThematiqueEntry(o: any): ShadowRoot;
    function _createEmptyThematique(): HTMLDivElement;
    function _createIndicatorElement(): HTMLDivElement;
}
//# sourceMappingURL=IndicatorDOM.d.ts.map